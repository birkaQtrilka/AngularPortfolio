using System;
using System.Collections.Generic;

public static class MyExtensions 
{
    //public static List<int> RemoveAllSpecifiedIndicesFromArray(this int[] a, bool[] indicesToRemove,int l)
    //{
    //    var b = new List<int>();
    //    for (int i = 0; i < l; ++i)
    //    {
    //        if (!indicesToRemove[i])
    //            b.Add(a[i]);
    //    }
    //    return b;
    //}
    //public static List<int> IndexOf(this Array a, object o)
    //{
    //    var result = new List<int>();//create a bag and add to it
    //    for (int i = 0; i < a.Length; ++i)
    //    {
    //        if (a.GetValue(i).Equals(o))
    //        {
    //            result.Add(i);
    //        }
    //    }
    //    //result.Sort();
    //    return result;
    //}
}
